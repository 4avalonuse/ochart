<?php
// ochart/api/yahoo.php — proxy com cache, fallback anti-429 e HEADERS de telemetria
header('Content-Type: application/json; charset=utf-8');
date_default_timezone_set('UTC');

$symbol   = $_GET['symbol'] ?? 'BTC-USD';
$interval = $_GET['interval'] ?? '1d';
$range    = $_GET['range'] ?? defaultRange($interval);

$allowedSymbols   = ['BTC-USD'];
$allowedIntervals = ['1h','60m','1d','1wk','1w','1mo'];
if (!in_array($symbol, $allowedSymbols)) { http_response_code(400); echo json_encode(err('param_symbol_not_allowed')); exit; }
if (!in_array($interval, $allowedIntervals)) { http_response_code(400); echo json_encode(err('param_interval_not_allowed')); exit; }

$yInterval = normalizeInterval($interval);
if ($yInterval === '60m' && !in_array($range, ['1d','5d','1mo','3mo'])) { $range = '1mo'; }

$cacheDir  = __DIR__ . DIRECTORY_SEPARATOR . 'cache';
if (!is_dir($cacheDir)) { @mkdir($cacheDir, 0777, true); }
$cacheKey  = safeKey($symbol.'_'.$yInterval.'_'.$range).'.json';
$cacheFile = $cacheDir . DIRECTORY_SEPARATOR . $cacheKey;
$ttl       = ttlFor($yInterval, $range);
$now       = time();

// 1) HIT
if (is_file($cacheFile) && ($now - filemtime($cacheFile) < $ttl)) {
  $payload = json_decode(file_get_contents($cacheFile), true);
  $payload['meta']['cache'] = 'HIT';
  sendCacheHeaders('HIT', $now - filemtime($cacheFile), $ttl, $yInterval, $range, 0, null);
  echo json_encode($payload);
  exit;
}

// 2) MISS
try {
  $out = tryFetchWithFallback($symbol, $yInterval, $range);
  $out['meta']['cache'] = 'MISS';
  $adjusted = isset($out['meta']['range_in']) ? (int)($out['meta']['range_in'] !== $range) : 0;
  file_put_contents($cacheFile, json_encode($out));
  sendCacheHeaders('MISS', 0, $ttl, ($out['meta']['interval_in'] ?? $yInterval), ($out['meta']['range_in'] ?? $range), $adjusted, null);
  echo json_encode($out);
  exit;
} catch (Exception $e) {
  // 3) STALE ou BYPASS
  if (is_file($cacheFile)) {
    $payload = json_decode(file_get_contents($cacheFile), true);
    $payload['meta']['cache'] = 'STALE';
    $payload['meta']['error'] = $e->getMessage();
    sendCacheHeaders('STALE', $now - filemtime($cacheFile), $ttl, $yInterval, $range, 0, $e->getMessage());
    echo json_encode($payload);
    exit;
  }
  if ($yInterval === '60m') {
    try {
      $out = fetchPack($symbol, '1d', '6mo');
      $out['meta']['cache'] = 'BYPASS';
      $out['meta']['degraded_from'] = $yInterval.' '.$range;
      sendCacheHeaders('BYPASS', 0, 0, '1d', '6mo', 1, 'degraded_from_60m');
      echo json_encode($out);
      exit;
    } catch (Exception $e2) {}
  }
  http_response_code(500);
  sendCacheHeaders('ERROR', 0, 0, $yInterval, $range, 0, $e->getMessage());
  echo json_encode(['error'=>'upstream','message'=>$e->getMessage(),'interval'=>$yInterval,'range'=>$range]);
  exit;
}

// ——— helpers ———
function safeKey($s){ return preg_replace('/[^a-zA-Z0-9_\-\.]+/','-', $s); }
function normalizeInterval($i){ if ($i === '1h') return '60m'; if ($i === '1w') return '1wk'; return $i; }
function defaultRange($interval){
  $i = normalizeInterval($interval);
  switch ($i) { case '60m': return '1mo'; case '1d': return '6mo'; case '1wk': return '2y'; case '1mo': return '5y'; default: return '1mo'; }
}
function ttlFor($interval, $range){
  if ($interval === '60m') return 300;     // 5 min
  if ($interval === '1d')  return 900;     // 15 min
  if ($interval === '1wk') return 3600;    // 1 h
  if ($interval === '1mo') return 21600;   // 6 h
  return 900;
}
function sendCacheHeaders($cache, $age, $ttl, $interval, $range, $adjusted, $error){
  header('X-Cache: '.strtoupper($cache));
  header('X-Cache-Age: '.intval($age));
  header('X-Cache-TTL: '.intval($ttl));
  header('X-Interval: '.$interval);
  header('X-Range: '.$range);
  header('X-Range-Adjusted: '.($adjusted ? '1':'0'));
  if ($error) header('X-Error: '.$error);
}
function tryFetchWithFallback($symbol, $interval, $range){
  if ($interval === '60m') {
    $candidates = [$range, '1mo', '5d', '1d'];
    $last = null; $seen = [];
    foreach ($candidates as $r) {
      if (isset($seen[$r])) continue; $seen[$r] = true;
      try { return fetchPack($symbol, $interval, $r); } catch (Exception $e) { $last = $e; }
    }
    throw $last ?: new Exception('yahoo_unknown_failure');
  }
  return fetchPack($symbol, $interval, $range);
}
function fetchPack($symbol, $interval, $range){
  $raw = fetchYahooChart($symbol, $interval, $range);
  validateYahoo($raw);
  $out = normalizeYahoo($raw, $symbol, $interval);
  $out['meta']['interval_in'] = $interval;
  $out['meta']['range_in']    = $range;
  return $out;
}
function fetchYahooChart($symbol, $interval, $range){
  $base = 'https://query1.finance.yahoo.com/v8/finance/chart/';
  $params = http_build_query([ 'interval'=>$interval, 'range'=>$range ]);
  $url = $base . urlencode($symbol) . '?' . $params;

  $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36';
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT => 8,
    CURLOPT_CONNECTTIMEOUT => 6,
    CURLOPT_HTTPHEADER => ['Accept: application/json','User-Agent: '.$ua,'Accept-Language: en-US,en;q=0.9'],
  ]);
  $res = curl_exec($ch);
  if ($res === false) throw new Exception('yahoo_network_error');
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if ($code < 200 || $code >= 300) throw new Exception('yahoo_http_error_'.$code);
  $json = json_decode($res, true);
  if (!$json) throw new Exception('yahoo_empty_body');
  return $json;
}
function validateYahoo($raw){
  $err = $raw['chart']['error'] ?? null;
  if ($err) throw new Exception('yahoo_upstream_error');
  $r  = $raw['chart']['result'][0] ?? null;
  if (!$r) throw new Exception('yahoo_no_result');
  $ts = $r['timestamp'] ?? [];
  if (!is_array($ts) || !count($ts)) throw new Exception('yahoo_no_timestamps');
  $q = $r['indicators']['quote'][0] ?? [];
  foreach (['open','high','low','close','volume'] as $k) {
    $arr = $q[$k] ?? [];
    if (count($arr) && count($arr) !== count($ts)) {
      throw new Exception('yahoo_misaligned_'.$k);
    }
  }
}
function normalizeYahoo($raw, $symbol, $interval){
  $r  = $raw['chart']['result'][0];
  $q  = $r['indicators']['quote'][0] ?? [];
  $ts = $r['timestamp'] ?? [];
  $o  = $q['open'] ?? []; $h = $q['high'] ?? []; $l = $q['low'] ?? []; $c = $q['close'] ?? []; $v = $q['volume'] ?? [];
  $data = [];
  $N = count($ts);
  for($i=0; $i<$N; $i++){
    $data[] = [
      't' => intval($ts[$i]) * 1000,
      'o' => num($o[$i] ?? null), 'h' => num($h[$i] ?? null),
      'l' => num($l[$i] ?? null), 'c' => num($c[$i] ?? null),
      'v' => num($v[$i] ?? null)
    ];
  }
  return [ 'meta'=>[ 'symbol'=>$symbol, 'interval'=>$interval, 'fetchedAt'=>round(microtime(true)*1000) ], 'data'=>$data ];
}
function num($x){ return is_numeric($x) ? floatval($x) : null; }
function err($code){ return ['error'=>$code]; }
