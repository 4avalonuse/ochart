export class ChartControls {
  constructor(rootEl, callbacks={}){
    this.root = rootEl; this.cb = callbacks;
    this.state = { scale:'logarithmic', type:'line', showVolume:false, autoRefresh:false, symbol:'BTC-USD' };
    this.render(); this.bind();
  }
  render(){
    this.root.innerHTML = `
      <div class="oc-toolbar" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <div><small>Escala</small><br/>
          <div class="oc-seg">
            <button data-scale="linear">Linear</button>
            <button data-scale="logarithmic" class="active">Log</button>
          </div>
        </div>
        <div><small>Tipo</small><br/>
          <div class="oc-seg">
            <button data-type="line" class="active">Linha</button>
            <button data-type="candlestick">Candle</button>
          </div>
        </div>
        <button id="oc-reset" class="oc-btn">Reset Zoom</button>
        <button id="oc-tv" class="oc-btn oc-primary">TradingView</button>
        <label class="oc-inline"><input id="oc-auto" type="checkbox"> Auto-refresh</label>
        <span id="oc-status" style="opacity:.7"></span>
      </div>
      <style>
        .oc-btn{background:#1f2937;color:#e5e7eb;border:1px solid #334155;padding:8px 10px;border-radius:8px;cursor:pointer}
        .oc-primary{background:#2563eb;border-color:#2563eb}
        .oc-seg{display:inline-flex;border:1px solid #334155;border-radius:10px;overflow:hidden}
        .oc-seg button{background:#111827;color:#e5e7eb;border:0;padding:8px 12px;cursor:pointer}
        .oc-seg button.active{background:#2563eb}
        .oc-inline{display:inline-flex;gap:6px;align-items:center}
      </style>`;
  }
  bind(){
    this.root.querySelectorAll('[data-scale]').forEach(b=> b.onclick = ()=> this.setScale(b.dataset.scale));
    this.root.querySelectorAll('[data-type]').forEach(b=> b.onclick = ()=> this.setType(b.dataset.type));
    this.root.querySelector('#oc-reset').onclick = ()=> this.cb.onZoomReset && this.cb.onZoomReset();
    this.root.querySelector('#oc-tv').onclick = ()=> this.cb.onTradingView ? this.cb.onTradingView(this.state.symbol) : window.open('https://www.tradingview.com/chart/?symbol=BINANCE:BTCUSDT','_blank');
    this.root.querySelector('#oc-auto').onchange = (e)=>{ this.state.autoRefresh=!!e.target.checked; this.cb.onRefreshToggle && this.cb.onRefreshToggle(this.state.autoRefresh); this.setStatus(this.state.autoRefresh?'Auto-refresh ON':'Auto-refresh OFF'); };
  }
  setSymbol(sym){ this.state.symbol=sym; }
  setScale(scale){ this.state.scale=scale; this.cb.onScaleChange && this.cb.onScaleChange(scale); this._sync(); this.setStatus(`Escala: ${scale==='logarithmic'?'Log':'Linear'}`); }
  setType(type){ this.state.type=type; this cb.onTypeChange && this.cb.onTypeChange(type); this._sync(); this.setStatus(`Tipo: ${type==='candlestick'?'Candle':'Linha'}`); }
  _sync(){ this.root.querySelectorAll('[data-scale]').forEach(b=> b.classList.toggle('active', b.dataset.scale===this.state.scale)); this.root.querySelectorAll('[data-type]').forEach(b=> b.classList.toggle('active', b.dataset.type===this.state.type)); }
  setStatus(t){ const el=this.root.querySelector('#oc-status'); if(el) el.textContent=t||''; }
  destroy(){ this.root.innerHTML=''; }
}
