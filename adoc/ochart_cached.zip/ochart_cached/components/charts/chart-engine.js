(function ensurePlugins(){
  if (typeof Chart !== 'undefined') {
    if (window['chartjs-plugin-zoom']) { Chart.register(window['chartjs-plugin-zoom']); }
    if (window['chartjs-plugin-annotation']) { Chart.register(window['chartjs-plugin-annotation']); }
    if (window['chartjs-chart-financial']) { /* noop for compat */ }
  }
})();

export class ChartEngine {
  constructor(canvasEl) {
    this.canvas = canvasEl;
    this.chart = null;
    this.currentData = [];
    this.currentConfig = { type:'line', scale:'logarithmic', showVolume:false };
    this.callbacks = { onZoom:null, onPan:null, onDataClick:null, onReset:null };
    this._overlays = []; this._drawings = [];
  }
  create(data, config={}){
    this.destroy();
    this.currentConfig = { ...this.currentConfig, ...config };
    this.currentData = Array.isArray(data) ? data : [];
    const cfg = this._buildChartConfig(this._datasetFromState(), this._maDatasets(), this._annotations());
    const ctx = this.canvas.getContext('2d');
    this.chart = new Chart(ctx, cfg);
    return this.chart;
  }
  update(data){
    if(!this.chart) return;
    this.currentData = Array.isArray(data) ? data : [];
    this.chart.data.datasets = [...this._datasetFromState(), ...this._maDatasets()];
    this.chart.options.scales.y.type = (this.currentConfig.scale === 'logarithmic' ? 'logarithmic' : 'linear');
    this.chart.options.plugins.annotation = this.chart.options.plugins.annotation || {};
    this.chart.options.plugins.annotation.annotations = this._annotations();
    this.chart.update('none');
  }
  destroy(){ if(this.chart){ this.chart.destroy(); this.chart=null; } }
  setScale(scale){
    if(!this.chart) return;
    if(scale==='logarithmic'){
      const bad = this.currentData.some(d=> (d.c ?? d.close ?? 0) <= 0);
      if(bad){ scale='linear'; }
    }
    this.currentConfig.scale = scale;
    this.chart.options.scales.y.type = (scale==='logarithmic'?'logarithmic':'linear');
    this.chart.update();
  }
  setType(type){
    if(!this.chart) return;
    this.currentConfig.type = (type==='candlestick'?'candlestick':'line');
    const z = this.getZoomState(); const data = this.currentData.slice(); const cfg = { ...this.currentConfig };
    this.create(data, cfg); if(z) this.setZoomState(z);
  }
  resetZoom(){ if(this.chart?.resetZoom){ this.chart.resetZoom(); this.callbacks.onReset && this.callbacks.onReset(); } }
  on(event, cb){ if(event in this.callbacks) this.callbacks[event]=cb; }
  setOverlays(o){ this._overlays = Array.isArray(o)?o:[]; this.update(this.currentData); }
  setDrawings(d){ this._drawings = Array.isArray(d)?d:[]; this.update(this.currentData); }
  _maDatasets(){
    const ov = this._overlays || [];
    const closes = this.currentData.map(d=> d.c ?? d.close);
    const out = [];
    for(const o of ov){
      const arr = (o.type==='EMA' ? ema(closes, o.period) : sma(closes, o.period));
      const data = arr.map((y,i)=> (Number.isFinite(y) ? { x: this.currentData[i].t ?? this.currentData[i].time, y } : null)).filter(Boolean);
      out.push({ type:'line', label:`${o.type}${o.period}`, data, borderColor:'#60a5fa', borderWidth:1.5, pointRadius:0, tension:0.15 });
    }
    return out;
  }
  _annotations(){
    const anns = {}; const ds = this._drawings || [];
    for(const d of ds){
      if(d.type==='hline'){ anns[d.id] = { type:'line', yMin:d.y, yMax:d.y, borderColor:'#c084fc', borderWidth:1.2 }; }
      else if(d.type==='trend'){ anns[d.id] = { type:'line', xMin:d.x1, xMax:d.x2, yMin:d.y1, yMax:d.y2, borderColor:'#f59e0b', borderWidth:1.2 }; }
    }
    return anns;
  }
  _datasetFromState(){
    if(this.currentConfig.type==='candlestick'){
      return [{ type:'candlestick', label:'Preço', data:this.currentData.map(d=>({x:d.t??d.time,o:d.o??d.open,h:d.h??d.high,l:d.l??d.low,c:d.c??d.close})), borderColor:'#9ca3af' }];
    }
    return [{ type:'line', label:'Close', data:this.currentData.map(d=>({x:d.t??d.time, y:d.c??d.close})), pointRadius:0, borderWidth:1 }];
  }
  _buildChartConfig(series, maSeries, annotations){
    return {
      data:{ datasets:[...series, ...maSeries] },
      options:{
        parsing:false, responsive:true, maintainAspectRatio:false,
        interaction:{ mode:'index', intersect:false },
        scales:{ x:{ type:'time', time:{unit:'day'}, ticks:{maxRotation:0}}, y:{ type:this.currentConfig.scale==='logarithmic'?'logarithmic':'linear' } },
        plugins:{
          legend:{ display:true },
          zoom:{ pan:{enabled:true,mode:'xy',onPan:()=>this.callbacks.onPan&&this.callbacks.onPan()}, zoom:{wheel:{enabled:true},pinch:{enabled:true},mode:'xy',onZoom:()=>this.callbacks.onZoom&&this.callbacks.onZoom()} },
          annotation:{ annotations }
        },
        onClick:(evt, els)=>{ if(els?.length && this.callbacks.onDataClick){ const i=els[0].index; this.callbacks.onDataClick({ index:i, row:this.currentData[i] }); } }
      }
    };
  }
  getZoomState(){ const s=this.chart?.scales?.x; return s?{min:s.min,max:s.max}:null; }
  setZoomState(st){ if(!this.chart||!st) return; if(this.chart.zoomScale){ this.chart.zoomScale('x',{min:st.min,max:st.max}); } }
}

export function sma(values, period){
  const out = Array(values.length).fill(undefined); let sum=0, q=[];
  for(let i=0;i<values.length;i++){ const v=Number(values[i]); if(!Number.isFinite(v)){ q=[]; sum=0; continue; } q.push(v); sum+=v; if(q.length>period){ sum-=q.shift(); } if(q.length===period){ out[i]=sum/period; } }
  return out;
}
export function ema(values, period){
  const out = Array(values.length).fill(undefined); const k = 2/(period+1); let prev;
  for(let i=0;i<values.length;i++){ const v=Number(values[i]); if(!Number.isFinite(v)){ prev=undefined; continue; } prev = (prev==null)? v : (v*k + prev*(1-k)); out[i]=prev; }
  return out;
}
